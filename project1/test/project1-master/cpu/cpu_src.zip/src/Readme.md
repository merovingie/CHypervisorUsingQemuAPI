## Project Instruction Updates:

Logic and alogrithms. I set a threshold and calculated the difference between busiest and freest virtual cpu if it exceeds threshold i start creating arrays of all cpus usage in the virtual and physical realm. then i assigned least busiest from virtual cpu to the busiest physical cpu and vise versa for all the arrays. 
i didnt have time to clean the code from all my trials and errors. there is some functions i created that i didnt use but i tested a lot of stuff. so sorry about that.
